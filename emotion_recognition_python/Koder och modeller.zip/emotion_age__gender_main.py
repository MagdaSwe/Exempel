import numpy as np
import cv2
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array

# Ladda modeller
emotion_model_path = r'C:\Users\magda\projekt\my_model_3_1.h5'

gender_age_model_path = r'C:\Users\magda\projekt\model_age_gender_0530.h5'

# Ladda modellerna
emotion_classifier = load_model(emotion_model_path, compile=False)
gender_age_classifier = load_model(gender_age_model_path, compile=False)

# Etiketter för känslor och kön
emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Neutral', 'Sad', 'Surprise']
gender_labels = ['Male', 'Female']

def preprocess_input(face_img, target_size, color_mode='rgb'):
    # Skala om och normalisera bilden
    face_img = cv2.resize(face_img, target_size)
    face_img = face_img.astype('float32') / 255.0

    # Om känslomodellen använder gråskala
    if color_mode == 'grayscale':
        if face_img.shape[-1] == 3:
            face_img = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)
        face_img = np.expand_dims(face_img, axis=-1)  # Lägg till kanalaxeln

    # För RGB, kontrollera och justera kanalerna
    elif color_mode == 'rgb':
        if face_img.shape[-1] != 3:
            face_img = cv2.cvtColor(face_img, cv2.COLOR_GRAY2BGR)  # Om ursprungligen gråskala, konvertera till RGB

    # Lägg till batchdimensionen
    face_img = np.expand_dims(face_img, axis=0)
    return face_img

def predict_emotion(face_img):
    preprocessed_img = preprocess_input(face_img, (48, 48), color_mode='grayscale')  # Använd gråskala för emotion-modellen
    emotion_prediction = emotion_classifier.predict(preprocessed_img)
    emotion_label_arg = np.argmax(emotion_prediction)
    return emotion_labels[emotion_label_arg]

def predict_gender_age(face_img):
    preprocessed_img = preprocess_input(face_img, (128, 128), color_mode='rgb')  # Använd RGB för gender/age-modellen
    gender_pred, age_pred = gender_age_classifier.predict(preprocessed_img)
    gender = gender_labels[int(np.round(gender_pred[0][0]))]
    age = int(age_pred[0][0])
    return gender, age

def main():
    # Ladda Haarcascades för ansiktsdetektion
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            break
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            face_img = frame[y:y + h, x:x + w]  # Använd färgbilden här för att visa korrekt ansikte i ramen
            gray_face_img = gray[y:y + h, x:x + w]  # Använd gråskala för förutsägelser

            emotion = predict_emotion(gray_face_img)
            gender, age = predict_gender_age(gray_face_img)

            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
            cv2.putText(frame, f'Emotion: {emotion}', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36, 255, 12), 2)
            cv2.putText(frame, f'Age: {age}', (x, y + h + 20), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36, 255, 12), 2)
            cv2.putText(frame, f'Gender: {gender}', (x, y + h + 50), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36, 255, 12), 2)

        cv2.imshow('Age, Gender, and Emotion Detection', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
