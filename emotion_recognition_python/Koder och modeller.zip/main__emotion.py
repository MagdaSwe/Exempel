import os
import cv2
from tensorflow.keras.models import load_model
from time import sleep
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.preprocessing import image
import numpy as np

# Kontrollera att Haar Cascade-filen finns

#cascade_path = r'C:\Users\magda\projekt\haarcascade_frontalface_default.xml'
cascade_path = r'C:/Users/magda/projekt/haarcascade_frontalface_default.xml'
print(f"Checking if the cascade file exists at: {cascade_path}")

if os.path.exists(cascade_path):
    print("Cascade file found")
else:
    print("Cascade file not found, please check the path")

face_classifier = cv2.CascadeClassifier(cascade_path)
if face_classifier.empty():
    print("Error loading cascade classifier")
else:
    print("Cascade classifier loaded successfully")

# Ladda den sparade modellen
model_path = r'C:\Users\magda\projekt\model.keras'
#model_path = r'C:/Users/magda/project/model.keras'
classifier =load_model(r'C:\Users\magda\projekt\my_model_3_1.h5')
#classifier = load_model(model_path)
print("Model loaded successfully")

# Lista över känsloetiketter
emotion_labels = ['Angry','Disgust','Fear','Happy','Neutral', 'Sad', 'Surprise']

# Starta videoinspelning
cap = cv2.VideoCapture(0)

while True:
    _, frame = cap.read()
    labels = []
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_classifier.detectMultiScale(gray)

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 255), 2)
        roi_gray = gray[y:y + h, x:x + w]
        roi_gray = cv2.resize(roi_gray, (48, 48), interpolation=cv2.INTER_AREA)

        if np.sum([roi_gray]) != 0:
            roi = roi_gray.astype('float') / 255.0
            roi = img_to_array(roi)
            roi = np.expand_dims(roi, axis=0)

            prediction = classifier.predict(roi, verbose=0)[0]
            label = emotion_labels[prediction.argmax()]
            label_position = (x, y)
            cv2.putText(frame, label, label_position, cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        else:
            cv2.putText(frame, 'No Faces', (30, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
    cv2.imshow('Emotion Detector', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
